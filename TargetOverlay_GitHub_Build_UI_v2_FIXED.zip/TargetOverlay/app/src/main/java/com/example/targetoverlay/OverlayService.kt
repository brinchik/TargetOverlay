package com.example.targetoverlay

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

class OverlayService : Service() {
    companion object { const val ACTION_START = "com.example.targetoverlay.START"; private const val WRAP = WindowManager.LayoutParams.WRAP_CONTENT }
    private lateinit var wm: WindowManager
    private lateinit var canvasView: MarkerCanvas
    private lateinit var canvasParams: WindowManager.LayoutParams
    private lateinit var panel: LinearLayout
    private lateinit var addButton: TextView
    private lateinit var deleteButton: TextView
    private var mode = Mode.NONE
    private val markers = mutableListOf<Marker>()
    private val handles = mutableListOf<MarkerHandle>()
    private enum class Mode { NONE, ADD, DELETE }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { if (!::wm.isInitialized) createOverlay(); return START_STICKY }

    private fun createOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        loadMarkers()
        canvasView = MarkerCanvas()
        canvasParams = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        wm.addView(canvasView, canvasParams)
        panel = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(2, 2, 2, 2); setBackgroundColor(Color.TRANSPARENT) }
        addButton = panelButton("ДОБАВИТЬ") { setMode(if (mode == Mode.ADD) Mode.NONE else Mode.ADD) }
        deleteButton = panelButton("УДАЛИТЬ") { setMode(if (mode == Mode.DELETE) Mode.NONE else Mode.DELETE) }
        panel.addView(addButton, LinearLayout.LayoutParams(WRAP, 48)); panel.addView(deleteButton, LinearLayout.LayoutParams(WRAP, 48))
        val pp = WindowManager.LayoutParams(WRAP, WRAP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.END; x = 16; y = 90 }
        wm.addView(panel, pp)
        rebuildHandles(); updateButtons()
    }
    private fun panelButton(value: String, action: () -> Unit) = TextView(this).apply {
        text = value; textSize = 13f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(14, 0, 14, 0); setBackgroundColor(Color.TRANSPARENT); setOnClickListener { action() }
    }
    private fun updateButtons() {
        addButton.setTextColor(if (mode == Mode.ADD) 0xFF35D07F.toInt() else Color.WHITE)
        deleteButton.setTextColor(if (mode == Mode.DELETE) 0xFFFF5B65.toInt() else Color.WHITE)
    }
    private fun setMode(value: Mode) {
        mode = value; val active = mode != Mode.NONE
        canvasParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or if (!active) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0
        wm.updateViewLayout(canvasView, canvasParams)
        handles.forEach { it.setTouchEnabled(!active) }; updateButtons()
    }
    private fun addMarker(x: Float, y: Float) {
        val label = getSharedPreferences("overlay", MODE_PRIVATE).getString("label", "test") ?: "test"
        markers.add(Marker(x, y, label)); saveMarkers(); rebuildHandles(); canvasView.invalidate()
    }
    private fun deleteNearest(x: Float, y: Float) {
        val i = markers.indices.reversed().firstOrNull { abs(markers[it].x * canvasView.width - x) < 70 && abs(markers[it].y * canvasView.height - y) < 70 }
        if (i != null) { markers.removeAt(i); saveMarkers(); rebuildHandles(); canvasView.invalidate() }
    }
    private fun rebuildHandles() {
        handles.forEach { try { wm.removeView(it) } catch (_: Exception) {} }; handles.clear()
        markers.forEachIndexed { index, m ->
            val h = MarkerHandle(index); val p = WindowManager.LayoutParams(150, 90, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
                .apply { gravity = Gravity.TOP or Gravity.START; x = (m.x * screenW() - 45).toInt(); y = (m.y * screenH() - 45).toInt() }
            h.paramsRef = p; handles.add(h); wm.addView(h, p); h.setTouchEnabled(mode == Mode.NONE)
        }
    }
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels
    private fun saveMarkers() {
        val a = JSONArray(); markers.forEach { a.put(JSONObject().put("x", it.x).put("y", it.y).put("label", it.label)) }
        getSharedPreferences("overlay", MODE_PRIVATE).edit().putString("markers", a.toString()).apply()
    }
    private fun loadMarkers() {
        try { val a = JSONArray(getSharedPreferences("overlay", MODE_PRIVATE).getString("markers", "[]") ?: "[]")
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); markers.add(Marker(o.getDouble("x").toFloat(), o.getDouble("y").toFloat(), o.optString("label", "test"))) }
        } catch (_: Exception) {}
    }
    inner class MarkerCanvas : View(this) {
        private val cross = Paint(3).apply { color = Color.rgb(40, 150, 255); strokeWidth = 3f; style = Paint.Style.STROKE }
        private val labelPaint = Paint(3).apply { color = Color.WHITE; textSize = 30f; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD); setShadowLayer(4f, 1f, 1f, Color.BLACK) }
        override fun onDraw(c: Canvas) { super.onDraw(c); markers.forEach { m -> val x=m.x*width; val y=m.y*height; c.drawCircle(x,y,22f,cross); c.drawLine(x-34,y,x+34,y,cross); c.drawLine(x,y-34,x,y+34,cross); c.drawText(m.label,x+30,y-28,labelPaint) } }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.action == MotionEvent.ACTION_UP) { when(mode) { Mode.ADD -> { addMarker(e.x/width.coerceAtLeast(1), e.y/height.coerceAtLeast(1)); setMode(Mode.NONE) }; Mode.DELETE -> { deleteNearest(e.x,e.y); setMode(Mode.NONE) }; else -> return false } }
            return true
        }
    }
    inner class MarkerHandle(private val index: Int) : View(this) {
        var paramsRef: WindowManager.LayoutParams? = null; private var enabled = true
        private var rawX=0f; private var rawY=0f; private var originX=0; private var originY=0
        fun setTouchEnabled(value: Boolean) { enabled=value; val p=paramsRef?:return; p.flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or if(!value) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0; try { wm.updateViewLayout(this,p) } catch (_:Exception){} }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (!enabled || index !in markers.indices) return false; val p=paramsRef?:return false
            when(e.action) {
                MotionEvent.ACTION_DOWN -> { rawX=e.rawX; rawY=e.rawY; originX=p.x; originY=p.y; return true }
                MotionEvent.ACTION_MOVE -> { p.x=originX+(e.rawX-rawX).toInt(); p.y=originY+(e.rawY-rawY).toInt(); wm.updateViewLayout(this,p); markers[index].x=((p.x+45f)/screenW()).coerceIn(0f,1f); markers[index].y=((p.y+45f)/screenH()).coerceIn(0f,1f); canvasView.invalidate(); return true }
                MotionEvent.ACTION_UP -> { saveMarkers(); return true }
            }; return true
        }
    }
    data class Marker(var x:Float,var y:Float,val label:String)
    override fun onDestroy() { if(::wm.isInitialized) { handles.forEach { try{wm.removeView(it)}catch(_:Exception){} }; try{wm.removeView(canvasView)}catch(_:Exception){}; try{wm.removeView(panel)}catch(_:Exception){} }; super.onDestroy() }
}

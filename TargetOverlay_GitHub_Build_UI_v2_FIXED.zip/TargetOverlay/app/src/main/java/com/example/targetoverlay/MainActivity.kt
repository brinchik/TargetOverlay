package com.example.targetoverlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("overlay", MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private lateinit var homeTab: TextView
    private lateinit var settingsTab: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 24); setBackgroundColor(0xFFF5F7FA.toInt()) }
        root.addView(TextView(this).apply { text = "Target Overlay"; textSize = 26f; setTextColor(0xFF17212B.toInt()); setPadding(0, 0, 0, 20) })
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        homeTab = tab("ГЛАВНАЯ") { showHome() }; settingsTab = tab("НАСТРОЙКИ") { showSettings() }
        tabs.addView(homeTab, LinearLayout.LayoutParams(0, 48, 1f)); tabs.addView(settingsTab, LinearLayout.LayoutParams(0, 48, 1f)); root.addView(tabs)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 24, 0, 0) }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f)); setContentView(root); showHome()
    }
    private fun tab(value: String, action: () -> Unit) = TextView(this).apply { text = value; gravity = Gravity.CENTER; textSize = 14f; setTypeface(null, android.graphics.Typeface.BOLD); setOnClickListener { action() } }
    private fun selectTab(selected: TextView) { listOf(homeTab, settingsTab).forEach { it.setTextColor(if (it == selected) 0xFF1976D2.toInt() else 0xFF65717D.toInt()); it.setBackgroundColor(if (it == selected) 0xFFE3F0FF.toInt() else 0) } }
    private fun showHome() {
        selectTab(homeTab); content.removeAllViews()
        content.addView(TextView(this).apply { text = "Метки можно сразу перетаскивать пальцем. Панель работает поверх других приложений."; textSize = 16f; setTextColor(0xFF263238.toInt()) })
        content.addView(Button(this).apply { text = "Разрешить отображение поверх окон"; setOnClickListener { if (!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) else Toast.makeText(this@MainActivity, "Разрешение уже выдано", Toast.LENGTH_SHORT).show() } })
        content.addView(Button(this).apply { text = "Запустить панель"; setOnClickListener { if (!Settings.canDrawOverlays(this@MainActivity)) Toast.makeText(this@MainActivity, "Сначала выдай разрешение", Toast.LENGTH_LONG).show() else { startService(Intent(this@MainActivity, OverlayService::class.java).setAction(OverlayService.ACTION_START)); finish() } } })
        content.addView(Button(this).apply { text = "Остановить панель"; setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) } })
    }
    private fun showSettings() {
        selectTab(settingsTab); content.removeAllViews()
        content.addView(TextView(this).apply { text = "Текст новой метки"; textSize = 18f; setTextColor(0xFF263238.toInt()) })
        val input = EditText(this).apply { hint = "Например: test"; setSingleLine(true); setText(prefs.getString("label", "test")) }
        content.addView(input, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        content.addView(Button(this).apply { text = "СОХРАНИТЬ"; setOnClickListener { prefs.edit().putString("label", input.text.toString().ifBlank { "test" }).apply(); Toast.makeText(this@MainActivity, "Текст метки сохранён", Toast.LENGTH_SHORT).show() } })
    }
}

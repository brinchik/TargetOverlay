package com.example.targetoverlay

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class OverlayService : Service() {
    companion object {
        const val ACTION_START = "com.example.targetoverlay.START"
        private const val WRAP = WindowManager.LayoutParams.WRAP_CONTENT
    }
    private lateinit var wm: WindowManager
    private lateinit var canvasView: MarkerCanvas
    private lateinit var canvasParams: WindowManager.LayoutParams
    private lateinit var panel: LinearLayout
    private lateinit var addButton: TextView
    private lateinit var deleteButton: TextView
    private var mode = Mode.NONE
    private val markers = mutableListOf<Marker>()
    private val handles = mutableListOf<MarkerHandle>()
    private val handler = Handler(Looper.getMainLooper())
    private var animationAngle = 0f
    private val animationTick = object : Runnable {
        override fun run() {
            if (markers.isNotEmpty() && currentReticle() == 9) {
                animationAngle = (animationAngle + 5f) % 360f
                canvasView.invalidate()
                handler.postDelayed(this, 40)
            }
        }
    }
    private enum class Mode { NONE, ADD, DELETE }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!::wm.isInitialized) createOverlay()
        return START_STICKY
    }

    private fun prefs() = getSharedPreferences("overlay", MODE_PRIVATE)
    private fun createOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        loadMarkers()
        canvasView = MarkerCanvas()
        canvasParams = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(canvasView, canvasParams)
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(2, 2, 2, 2)
            setBackgroundColor(Color.TRANSPARENT)
        }
        addButton = panelButton(prefs().getString("add_button", "ДОБАВИТЬ") ?: "ДОБАВИТЬ") {
            setMode(if (mode == Mode.ADD) Mode.NONE else Mode.ADD)
        }
        deleteButton = panelButton(prefs().getString("delete_button", "УДАЛИТЬ") ?: "УДАЛИТЬ") {
            if (markers.isNotEmpty()) setMode(if (mode == Mode.DELETE) Mode.NONE else Mode.DELETE)
        }
        panel.addView(addButton, LinearLayout.LayoutParams(WRAP, 48))
        panel.addView(deleteButton, LinearLayout.LayoutParams(WRAP, 48))
        val pp = WindowManager.LayoutParams(
            WRAP, WRAP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 16; y = 90 }
        wm.addView(panel, pp)
        rebuildHandles()
        updateButtons()
        if (currentReticle() == 9) handler.post(animationTick)
    }

    private fun panelButton(value: String, action: () -> Unit) = TextView(this).apply {
        text = value; textSize = 13f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE)
        gravity = Gravity.CENTER; setPadding(14, 0, 14, 0)
        setBackgroundColor(Color.TRANSPARENT); setOnClickListener { action() }
    }

    private fun updateButtons() {
        addButton.text = prefs().getString("add_button", "ДОБАВИТЬ") ?: "ДОБАВИТЬ"
        deleteButton.text = prefs().getString("delete_button", "УДАЛИТЬ") ?: "УДАЛИТЬ"
        addButton.setTextColor(if (mode == Mode.ADD) 0xFF35D07F.toInt() else Color.WHITE)
        deleteButton.setTextColor(if (mode == Mode.DELETE) 0xFFFF5B65.toInt() else Color.WHITE)
        deleteButton.alpha = if (markers.isEmpty()) 0.4f else 1f
    }

    private fun setMode(value: Mode) {
        mode = if (value == Mode.DELETE && markers.isEmpty()) Mode.NONE else value
        val active = mode != Mode.NONE
        canvasParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            if (!active) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0
        wm.updateViewLayout(canvasView, canvasParams)
        handles.forEach { it.setTouchEnabled(!active) }
        updateButtons()
    }

    private fun addMarker(x: Float, y: Float) {
        val label = prefs().getString("label", "") ?: ""
        val marker = Marker(x, y, label)
        markers.add(marker)
        saveMarkers(); rebuildHandles(); canvasView.invalidate(); updateButtons()
        if (prefs().getBoolean("auto_remove", false)) {
            val delay = prefs().getInt("remove_seconds", 10).coerceIn(1, 86400) * 1000L
            handler.postDelayed({
                if (markers.remove(marker)) {
                    saveMarkers(); rebuildHandles(); canvasView.invalidate()
                    if (markers.isEmpty() && mode == Mode.DELETE) setMode(Mode.NONE)
                    updateButtons()
                }
            }, delay)
        }
        if (currentReticle() == 9) handler.removeCallbacks(animationTick).also { handler.post(animationTick) }
    }

    private fun deleteNearest(x: Float, y: Float) {
        val i = markers.indices.reversed().firstOrNull {
            abs(markers[it].x * canvasView.width - x) < 70 &&
                abs(markers[it].y * canvasView.height - y) < 70
        }
        if (i != null) {
            markers.removeAt(i); saveMarkers(); rebuildHandles(); canvasView.invalidate()
            if (markers.isEmpty()) setMode(Mode.NONE) else updateButtons()
        }
    }

    private fun currentReticle() = prefs().getInt("reticle", 0).coerceIn(0, 9)
    private fun rebuildHandles() {
        handles.forEach { try { wm.removeView(it) } catch (_: Exception) {} }
        handles.clear()
        markers.forEachIndexed { index, m ->
            val h = MarkerHandle(index)
            val p = WindowManager.LayoutParams(
                150, 90, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = (m.x * screenW() - 45).toInt(); y = (m.y * screenH() - 45).toInt()
            }
            h.paramsRef = p; handles.add(h); wm.addView(h, p); h.setTouchEnabled(mode == Mode.NONE)
        }
    }
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels

    private fun saveMarkers() {
        val a = JSONArray()
        markers.forEach { a.put(JSONObject().put("x", it.x).put("y", it.y).put("label", it.label)) }
        prefs().edit().putString("markers", a.toString()).apply()
    }
    private fun loadMarkers() {
        try {
            val a = JSONArray(prefs().getString("markers", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                markers.add(Marker(o.getDouble("x").toFloat(), o.getDouble("y").toFloat(), o.optString("label", "")))
            }
        } catch (_: Exception) {}
    }

    inner class MarkerCanvas : View(this) {
        private val p = Paint(3).apply {
            color = Color.rgb(40, 220, 120); strokeWidth = 3f
            style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
        }
        private val textPaint = Paint(3).apply {
            color = Color.WHITE; textSize = 30f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setShadowLayer(4f, 1f, 1f, Color.BLACK)
        }
        private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) = c.drawLine(x1, y1, x2, y2, p)
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val style = currentReticle()
            markers.forEach { m ->
                val x = m.x * width; val y = m.y * height
                when (style) {
                    0 -> { line(c,x-34,y,x-8,y); line(c,x+8,y,x+34,y); line(c,x,y-34,x,y-8); line(c,x,y+8,x,y+34); c.drawCircle(x,y,5f,p) }
                    1 -> { line(c,x-30,y,x+30,y); line(c,x,y-30,x,y+30) }
                    2 -> c.drawCircle(x,y,25f,p)
                    3 -> { c.drawCircle(x,y,25f,p); c.drawCircle(x,y,4f,p) }
                    4 -> { val d=24f; val k=10f; line(c,x-d,y-d,x-d+k,y-d); line(c,x-d,y-d,x-d,y-d+k); line(c,x+d,y-d,x+d-k,y-d); line(c,x+d,y-d,x+d,y-d+k); line(c,x-d,y+d,x-d+k,y+d); line(c,x-d,y+d,x-d,y+d-k); line(c,x+d,y+d,x+d-k,y+d); line(c,x+d,y+d,x+d,y+d-k) }
                    5 -> { c.drawCircle(x,y,24f,p); line(c,x-38,y,x-9,y); line(c,x+9,y,x+38,y); line(c,x,y-38,x,y-9); line(c,x,y+9,x,y+38) }
                    6 -> { c.drawCircle(x,y,27f,p); line(c,x-42,y,x-12,y); line(c,x+12,y,x+42,y); line(c,x,y-42,x,y-12); line(c,x,y+12,x,y+42); c.drawCircle(x,y,3f,p) }
                    7 -> { val path=Path().apply { moveTo(x,y-30); lineTo(x+25,y+22); lineTo(x,y+12); lineTo(x-25,y+22); close() }; c.drawPath(path,p) }
                    8 -> { p.pathEffect=android.graphics.DashPathEffect(floatArrayOf(5f,6f),0f); c.drawCircle(x,y,25f,p); p.pathEffect=null; line(c,x-5,y,x+5,y); line(c,x,y-5,x,y+5) }
                    9 -> {
                        c.save(); c.rotate(animationAngle,x,y)
                        c.drawCircle(x,y,24f,p)
                        for (a in 0 until 4) { val angle=Math.toRadians((a*90).toDouble()); val sx=x+cos(angle).toFloat()*31f; val sy=y+sin(angle).toFloat()*31f; val ex=x+cos(angle).toFloat()*43f; val ey=y+sin(angle).toFloat()*43f; line(c,sx,sy,ex,ey) }
                        c.restore()
                    }
                }
                if (m.label.isNotEmpty()) c.drawText(m.label,x+32,y-28,textPaint)
            }
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.action == MotionEvent.ACTION_UP) {
                when (mode) {
                    Mode.ADD -> { addMarker(e.x/width.coerceAtLeast(1), e.y/height.coerceAtLeast(1)); setMode(Mode.NONE) }
                    Mode.DELETE -> deleteNearest(e.x,e.y)
                    else -> return false
                }
            }
            return mode != Mode.NONE
        }
    }

    inner class MarkerHandle(private val index: Int) : View(this) {
        var paramsRef: WindowManager.LayoutParams? = null
        private var enabled = true
        private var rawX=0f; private var rawY=0f; private var originX=0; private var originY=0
        fun setTouchEnabled(value: Boolean) {
            enabled=value; val p=paramsRef?:return
            p.flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                if(!value) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0
            try { wm.updateViewLayout(this,p) } catch (_:Exception) {}
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (!enabled || index !in markers.indices) return false
            val p=paramsRef?:return false
            when(e.action) {
                MotionEvent.ACTION_DOWN -> { rawX=e.rawX; rawY=e.rawY; originX=p.x; originY=p.y; return true }
                MotionEvent.ACTION_MOVE -> {
                    p.x=originX+(e.rawX-rawX).toInt(); p.y=originY+(e.rawY-rawY).toInt()
                    wm.updateViewLayout(this,p)
                    markers[index].x=((p.x+45f)/screenW()).coerceIn(0f,1f)
                    markers[index].y=((p.y+45f)/screenH()).coerceIn(0f,1f)
                    canvasView.invalidate(); return true
                }
                MotionEvent.ACTION_UP -> { saveMarkers(); return true }
            }
            return true
        }
    }
    data class Marker(var x:Float,var y:Float,val label:String)

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if(::wm.isInitialized) {
            handles.forEach { try{wm.removeView(it)}catch(_:Exception){} }
            try{wm.removeView(canvasView)}catch(_:Exception){}
            try{wm.removeView(panel)}catch(_:Exception){}
        }
        super.onDestroy()
    }
}

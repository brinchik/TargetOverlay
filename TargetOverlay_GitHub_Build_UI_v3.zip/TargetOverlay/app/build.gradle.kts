plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.targetoverlay"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.targetoverlay"
        minSdk = 26
        targetSdk = 32
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
        versionCode = 1
        versionName = "0.1.0"
    }
}


kotlin {
    jvmToolchain(17)
}

package com.example.targetoverlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var labelInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("overlay", MODE_PRIVATE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "Target Overlay"
            textSize = 26f
            setTextColor(0xFF17212B.toInt())
        }
        val info = TextView(this).apply {
            text = "Прозрачная разметка поверх другого приложения"
            textSize = 15f
            setPadding(0, 12, 0, 22)
        }
        labelInput = EditText(this).apply {
            hint = "Подпись новой метки"
            setText(prefs.getString("label", "test"))
            singleLine = true
        }
        val permission = Button(this).apply {
            text = "1. Разрешить отображение поверх окон"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Разрешение уже выдано", Toast.LENGTH_SHORT).show()
            }
        }
        val start = Button(this).apply {
            text = "2. Запустить панель Overlay"
            setOnClickListener {
                prefs.edit().putString("label", labelInput.text.toString().ifBlank { "test" }).apply()
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Сначала разреши отображение поверх окон", Toast.LENGTH_LONG).show()
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java).setAction(OverlayService.ACTION_START))
                    Toast.makeText(this@MainActivity, "Панель запущена", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
        val stop = Button(this).apply {
            text = "Остановить Overlay"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        val note = TextView(this).apply {
            text = "Как пользоваться: нажми ADD на плавающей панели, затем коснись нужного места на экране. Одно касание добавляет метку и возвращает управление основному приложению."
            textSize = 14f
            setPadding(0, 20, 0, 0)
        }

        listOf(title, info, labelInput, permission, start, stop, note).forEach {
            layout.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = 12
            })
        }
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}

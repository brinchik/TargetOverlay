package com.example.targetoverlay

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.view.*
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

class OverlayService : Service() {
    companion object {
        const val ACTION_START = "com.example.targetoverlay.START"
    }

    private lateinit var wm: WindowManager
    private lateinit var markerView: MarkerView
    private lateinit var markerParams: WindowManager.LayoutParams
    private lateinit var panel: LinearLayout
    private lateinit var panelParams: WindowManager.LayoutParams
    private var placementMode = false
    private var moveMode = false
    private var markersVisible = true
    private val markers = mutableListOf<Marker>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!::wm.isInitialized) createOverlay()
        return START_STICKY
    }

    private fun createOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        loadMarkers()

        markerView = MarkerView()
        markerParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(markerView, markerParams)

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(0xDD17212B.toInt())
        }
        val header = TextView(this).apply {
            text = "TARGET OVERLAY"
            setTextColor(Color.WHITE)
            textSize = 11f
            setTypeface(null, Typeface.BOLD)
            setPadding(8, 4, 8, 8)
        }
        panel.addView(header)
        addButton("ADD") {
            moveMode = false
            placementMode = !placementMode
            updateTouchMode()
            header.text = if (placementMode) "ADD: коснись экрана" else "TARGET OVERLAY"
        }
        addButton("MOVE") {
            placementMode = false
            moveMode = !moveMode
            updateTouchMode()
            header.text = if (moveMode) "MOVE: перетаскивай метки" else "TARGET OVERLAY"
        }
        addButton("HIDE / SHOW") {
            markersVisible = !markersVisible
            markerView.invalidate()
        }
        addButton("CLEAR") {
            markers.clear()
            saveMarkers()
            markerView.invalidate()
        }
        addButton("CLOSE") { stopSelf() }

        panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 18
            y = 100
        }
        wm.addView(panel, panelParams)
    }

    private fun addButton(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 10f
            isAllCaps = false
            setPadding(10, 0, 10, 0)
            setOnClickListener { action() }
        }
        panel.addView(b, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 42
        ))
    }

    private fun updateTouchMode() {
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            if (!placementMode && !moveMode) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0
        markerParams.flags = flags
        wm.updateViewLayout(markerView, markerParams)
    }

    private fun saveMarkers() {
        val arr = JSONArray()
        markers.forEach { m ->
            arr.put(JSONObject().put("x", m.x).put("y", m.y).put("label", m.label))
        }
        getSharedPreferences("overlay", MODE_PRIVATE).edit().putString("markers", arr.toString()).apply()
    }

    private fun loadMarkers() {
        val raw = getSharedPreferences("overlay", MODE_PRIVATE).getString("markers", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                markers.add(Marker(o.getFloat("x"), o.getFloat("y"), o.optString("label", "test")))
            }
        } catch (_: Exception) { }
    }

    inner class MarkerView : View(this) {
        private val cross = android.graphics.Paint(3).apply {
            color = Color.rgb(40, 150, 255)
            strokeWidth = 3f
            style = android.graphics.Paint.Style.STROKE
        }
        private val labelPaint = android.graphics.Paint(3).apply {
            color = Color.WHITE
            textSize = 30f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setShadowLayer(4f, 1f, 1f, Color.BLACK)
        }
        private var selected = -1
        private var lastX = 0f
        private var lastY = 0f

        override fun onDraw(canvas: android.graphics.Canvas) {
            super.onDraw(canvas)
            if (!markersVisible) return
            markers.forEach { m ->
                val x = m.x * width
                val y = m.y * height
                val r = 22f
                canvas.drawCircle(x, y, r, cross)
                canvas.drawLine(x - 34, y, x + 34, y, cross)
                canvas.drawLine(x, y - 34, x, y + 34, cross)
                canvas.drawText(m.label, x + 30, y - 28, labelPaint)
            }
        }

        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = event.x
                    lastY = event.y
                    if (placementMode) {
                        val label = getSharedPreferences("overlay", MODE_PRIVATE)
                            .getString("label", "test") ?: "test"
                        markers.add(Marker(event.x / width.coerceAtLeast(1), event.y / height.coerceAtLeast(1), label))
                        saveMarkers()
                        placementMode = false
                        updateTouchMode()
                        invalidate()
                        return true
                    }
                    if (moveMode) {
                        selected = markers.indices.reversed().firstOrNull { i ->
                            abs(markers[i].x * width - event.x) < 55 &&
                            abs(markers[i].y * height - event.y) < 55
                        } ?: -1
                        return selected >= 0
                    }
                }
                MotionEvent.ACTION_MOVE -> if (moveMode && selected >= 0) {
                    markers[selected].x = (event.x / width.coerceAtLeast(1)).coerceIn(0f, 1f)
                    markers[selected].y = (event.y / height.coerceAtLeast(1)).coerceIn(0f, 1f)
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_UP -> if (moveMode && selected >= 0) {
                    saveMarkers()
                    selected = -1
                    return true
                }
            }
            return moveMode
        }
    }

    data class Marker(var x: Float, var y: Float, val label: String)

    override fun onDestroy() {
        if (::wm.isInitialized) {
            try { if (::markerView.isInitialized) wm.removeView(markerView) } catch (_: Exception) {}
            try { if (::panel.isInitialized) wm.removeView(panel) } catch (_: Exception) {}
        }
        super.onDestroy()
    }
}

package com.example.targetoverlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("overlay", MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private lateinit var homeTab: TextView
    private lateinit var settingsTab: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        root.addView(TextView(this).apply {
            text = "Target Overlay"; textSize = 26f
            setTextColor(0xFF17212B.toInt()); setPadding(0, 0, 0, 20)
        })
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        homeTab = tab("ГЛАВНАЯ") { showHome() }
        settingsTab = tab("НАСТРОЙКИ") { showSettings() }
        tabs.addView(homeTab, LinearLayout.LayoutParams(0, 48, 1f))
        tabs.addView(settingsTab, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(tabs)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 24, 0, 24) }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        scroll.addView(content, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        showHome()
    }

    private fun tab(value: String, action: () -> Unit) = TextView(this).apply {
        text = value; gravity = Gravity.CENTER; textSize = 14f
        setTypeface(null, android.graphics.Typeface.BOLD); setOnClickListener { action() }
    }

    private fun selectTab(selected: TextView) {
        listOf(homeTab, settingsTab).forEach {
            it.setTextColor(if (it == selected) 0xFF1976D2.toInt() else 0xFF65717D.toInt())
            it.setBackgroundColor(if (it == selected) 0xFFE3F0FF.toInt() else 0)
        }
    }

    private fun showHome() {
        selectTab(homeTab); content.removeAllViews()
        content.addView(TextView(this).apply {
            text = "Метки можно сразу перетаскивать пальцем. Панель работает поверх других приложений."
            textSize = 16f; setTextColor(0xFF263238.toInt())
        })
        content.addView(Button(this).apply {
            text = "Разрешить отображение поверх окон"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity))
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                else Toast.makeText(this@MainActivity, "Разрешение уже выдано", Toast.LENGTH_SHORT).show()
            }
        })
        content.addView(Button(this).apply {
            text = "Запустить панель"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity))
                    Toast.makeText(this@MainActivity, "Сначала выдай разрешение", Toast.LENGTH_LONG).show()
                else { startService(Intent(this@MainActivity, OverlayService::class.java).setAction(OverlayService.ACTION_START)); finish() }
            }
        })
        content.addView(Button(this).apply {
            text = "Остановить панель"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
    }

    private fun showSettings() {
        selectTab(settingsTab); content.removeAllViews()
        fun caption(value: String) {
            content.addView(TextView(this).apply {
                text = value; textSize = 16f; setTextColor(0xFF263238.toInt())
                setPadding(0, 14, 0, 4)
            })
        }
        val labelInput = EditText(this).apply {
            hint = "Оставь пустым, если текст не нужен"
            setSingleLine(true); setText(prefs.getString("label", "") ?: "")
        }
        caption("Текст новой метки")
        content.addView(labelInput, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        val addName = EditText(this).apply {
            hint = "Название кнопки добавления"; setSingleLine(true)
            setText(prefs.getString("add_button", "ДОБАВИТЬ"))
        }
        caption("Название кнопки добавления")
        content.addView(addName, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        val deleteName = EditText(this).apply {
            hint = "Название кнопки удаления"; setSingleLine(true)
            setText(prefs.getString("delete_button", "УДАЛИТЬ"))
        }
        caption("Название кнопки удаления")
        content.addView(deleteName, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        val reticles = arrayOf(
            "Классический", "Тонкий крест", "Круг", "Круг с точкой", "Четыре угла",
            "Крест с кольцом", "Тактический", "Шеврон", "Пунктирный круг", "Вращающийся"
        )
        caption("Вид прицела")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, reticles)
        spinner.setSelection(prefs.getInt("reticle", 0).coerceIn(0, reticles.lastIndex))
        content.addView(spinner, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        val colorNames = arrayOf("Зелёный", "Красный", "Синий", "Жёлтый", "Белый", "Голубой", "Оранжевый", "Фиолетовый", "Розовый", "Лаймовый")
        caption("Цвет прицела")
        val colorSpinner = Spinner(this)
        colorSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, colorNames)
        colorSpinner.setSelection(prefs.getInt("reticle_color", 0).coerceIn(0, colorNames.lastIndex))
        content.addView(colorSpinner, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        caption("Автоматическое исчезновение метки")
        val autoSwitch = Switch(this).apply {
            text = "Включить исчезновение по таймеру"
            isChecked = prefs.getBoolean("auto_remove", false)
        }
        content.addView(autoSwitch)
        val seconds = EditText(this).apply {
            hint = "Секунд до исчезновения"; inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true); setText(prefs.getInt("remove_seconds", 10).toString())
        }
        content.addView(seconds, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        content.addView(Button(this).apply {
            text = "СОХРАНИТЬ НАСТРОЙКИ"
            setOnClickListener {
                val sec = seconds.text.toString().toIntOrNull()?.coerceIn(1, 86400) ?: 10
                prefs.edit()
                    .putString("label", labelInput.text.toString())
                    .putString("add_button", addName.text.toString().ifBlank { "ДОБАВИТЬ" })
                    .putString("delete_button", deleteName.text.toString().ifBlank { "УДАЛИТЬ" })
                    .putInt("reticle", spinner.selectedItemPosition)
                    .putInt("reticle_color", colorSpinner.selectedItemPosition)
                    .putBoolean("auto_remove", autoSwitch.isChecked)
                    .putInt("remove_seconds", sec)
                    .apply()
                Toast.makeText(this@MainActivity, "Настройки сохранены", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
